#include "funcs.h"

int main(void) {
    int res;
    char cmd[MAXCMD];
    struct cmdlist cmds;
    struct rlimit limit;
    getrlimit(RLIMIT_FSIZE, &limit);
    limit.rlim_cur = 50;
    setrlimit(RLIMIT_FSIZE, &limit);
    setupnewcommand(&cmds);

    while (1) {
        printprompt();
        if (readcmd(cmd, MAXCMD) == RESERROR)
            continue;
        res = parsecmd(cmd, MAXCMD, &cmds);
        printparsedcmds(&cmds);
        executecmds(&cmds);
        dealocate(&cmds);
    }

    return 0;
}

/*  */

void setupnewcommand(struct cmdlist* __cmd) {
    if (__cmd == NULL)
        return;

    __cmd->next = NULL;  
    __cmd->argv = NULL;  
    __cmd->conjuction = CONJUD;
    __cmd->argc = 0;
}


/* add the NULL pointer to the end of the list  */

int setupparsedcommand(struct cmdlist* __cmd) {
    if (__cmd == NULL) {
        printf("Null at setupparsedcommand.");
        return RESERROR;
    }

    __cmd->argc++;
    
     __cmd->argv = (char**) realloc(__cmd->argv, __cmd->argc * sizeof (char*));
    if (__cmd->argv == NULL) 
        return RESERROR;
    __cmd->argv[__cmd->argc - 1] = NULL; 

    return RESSUCCESS;
}
/*  */

/* reading command from the std input */
int readcmd(char* __buf, int __bufsize) {
    
    if (fgets(__buf, __bufsize, stdin) == NULL) {
        	printf("Error, try again!");
        
        	return RESERROR;
    }

    
	/* If the input buffer is not empty */
    if (strchr(__buf, '\n') == NULL) {
        while (1) {
            char c = getchar();
            if (c == '\n')
                break;
            else if ((c == EOF) && (ferror(stdin)))
                return RESERROR;
        }
        printf(
                "Line is too long.\nMaximal size is %d.",
                __bufsize - 2);
        return RESERROR;
    }
    return RESSUCCESS;
}
/* -------------------------------------------------------------------------------------- */

/* Parsing this command */
int parsecmd(char* __buf, int __bufsize, struct cmdlist* __head) {
    
	
	char* cmd = __buf; 
     
	 char* word; 
    struct cmdlist* curr = __head;
    struct cmdlist* tmp = NULL;

    while ((word = strtok(cmd, " \t\n")) != NULL) {

        /* && operator parsing  */
        if (strcmp(word, "&&") == 0) {
            tmp = (struct cmdlist*) malloc(sizeof (struct cmdlist));
            curr->next = tmp;
            if (setupparsedcommand(curr) == RESERROR)
                return RESERROR;
            curr = tmp;
            setupnewcommand(curr);
            curr->conjuction = CONJAND;
        
        } 
        /* || operator parsing  */
        else if (strcmp(word, "||") == 0) {
            tmp = (struct cmdlist*) malloc(sizeof (struct cmdlist));
            curr->next = tmp;
            if (setupparsedcommand(curr) == RESERROR)
                return RESERROR;
            curr = tmp;
            setupnewcommand(curr);
            curr->conjuction = CONJOR;
        } 
        
        else {
        	
            curr->argc++;
            curr->argv = (char**) realloc(curr->argv,
                    sizeof (char*) * curr->argc); 
            if (curr->argv == NULL) {
                printf("Error");
                return RESERROR;
            }
            curr->argv[curr->argc - 1] = word; 
            cmd = NULL;
        }
    }

    
    
	
	if (setupparsedcommand(curr) == RESERROR) {
        printf("Error.");
        return RESERROR;
    }
    return RESSUCCESS;
}

/*  */

/* Executing parsed commands */
int executecmds(struct cmdlist* __head) {

    int error, f, a;
    
    int procres = 0;
    int flag = 1;
    struct cmdlist* curr = __head;

    while (curr != NULL) {
        if ((curr->argv[0] != NULL) && (strcmp(curr->argv[0], "exit") == 0)){
            exit(EXIT_SUCCESS);
        }
            

        if (procres) {
            if ((curr->conjuction == CONJAND) && (WEXITSTATUS(a) != 0))
                flag = 0;
            else if ((curr->conjuction == CONJOR) && (WEXITSTATUS(a) == 0))
                flag = 0;
        }
        if (flag) {
            f = fork();
            error = errno;
            
            if (f == -1) {
                printf("Fork error: %s", strerror(error));
                return RESERROR;
                
                
            }

            if (f == 0) {
                execvp(curr->argv[0], curr->argv);
                error = errno;
                printf("Error while executing: %s", strerror(error));
                exit(EXIT_FAILURE);
            }
            
            
            if (wait(&a) == -1) {
                printf("Error: %s", strerror(error));
                return RESERROR;
            }
            procres = WIFEXITED(a) ? 1 : 0;
            if (procres)
                printf("%d \n", WEXITSTATUS(a));
        }
        curr = curr->next;
        flag = 1;

    }
    return RESSUCCESS;
}
